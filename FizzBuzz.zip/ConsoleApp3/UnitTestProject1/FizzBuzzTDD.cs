﻿using System;
using System.Collections.Generic;
using ConsoleApp3;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTestProject1
{
    [TestClass]
    public class FizzBuzzTDD
    {
        [TestMethod]
        public void QuandoPedirOPrimeiroNumero_RetornaApenas1()
        {
            //Arrange
            FizzBuzz fizz1 = new FizzBuzz();
            //Assert
            Assert.AreEqual("1", fizz1.CriarLista()[0]);
        }
        [TestMethod]
        public void QuandoPedirOSegundoNumero_RetornaApenas2()
        {
            //Arrange
            FizzBuzz fizz1 = new FizzBuzz();
            
            //Assert
            Assert.AreEqual("2", fizz1.CriarLista()[1]);
        }
        [TestMethod]
        public void QuandoPedirOTerceiroNumero_RetornaFizz()
            //O terceiro numero da lista seria o numero 3, e por ser divisivel apenas por 3 deve aparecer a palavra "FIZZ" ao invez do numero 3.
        {
            //Arrange
            FizzBuzz fizz1 = new FizzBuzz();

            //Assert
            Assert.AreEqual("Fizz", fizz1.CriarLista()[2]);
        }
        [TestMethod]
        public void QuandoPedirOQuartoNumero_RetornaApenas4()
        {
            //Arrange
            FizzBuzz fizz1 = new FizzBuzz();

            //Assert
            Assert.AreEqual("4", fizz1.CriarLista()[3]);
        }
        [TestMethod]
        public void QuandoPedirOQuintoNumero_RetornaBuzz()
        //O quinto numero da lista seria o numero 5, e por ser divisivel apenas por 5 deve aparecer a palavra "Buzz" ao invez do numero 5.
        {
            //Arrange
            FizzBuzz fizz1 = new FizzBuzz();

            //Assert
            Assert.AreEqual("Buzz", fizz1.CriarLista()[4]);
        }
        [TestMethod]
        public void QuandoPedirOSextoNumeroEoNonoNumero_RetornaFizz()
        //Os numeros 6 e 9 sáo divisiveis por 3 e não são diviseis por 5 e por isso deve aparecer a palavra "FIZZ" ao invez dos respectivos numeros.
        {
            //Arrange
            FizzBuzz fizz1 = new FizzBuzz();
            //Assert
            Assert.AreEqual("Fizz", fizz1.CriarLista()[5]);
            Assert.AreEqual("Fizz", fizz1.CriarLista()[8]);
        }
        [TestMethod]
        public void QuandoPedirONumero15_RetornaFizzBuzz()
        //O numero 15 é divisivel por 3 e por 5 e portanto deve aparecer a palavra "FIZZBUZZ" ao invez do numero 15 em si.
        {
            //Arrange
            FizzBuzz fizz1 = new FizzBuzz();

            //Assert
            Assert.AreEqual("FizzBuzz", fizz1.CriarLista()[14]);            
        }
        [TestMethod]
        public void QuandoVerificarOTamanhoDoVetor_Retorna100()
        {
            FizzBuzz fizz1 = new FizzBuzz();
            Assert.AreEqual(100, fizz1.CriarLista().Count);
        }
        [TestMethod]
        public void QuandoPedirONumero30_RetornaFizzBuzz()
        //O numero 30 é divisível por 3 e por 5 e portanto deve aparecer a palavra "FIZZBUZZ" ao inves do numero 30 em si.
        {
            //Arrange
            FizzBuzz fizz1 = new FizzBuzz();
            //Assert
            Assert.AreEqual("FizzBuzz", fizz1.CriarLista()[29]);
        }
        [TestMethod]
        public void QuandoPedirONumero50_RetornaBuzz()
        //Os numeros 6 e 9 sáo divisiveis por 3 e não são diviseis por 5 e por isso deve aparecer a palavra "FIZZ" ao invez dos respectivos numeros.
        {
            //Arrange
            FizzBuzz fizz1 = new FizzBuzz();
            //Assert
            Assert.AreEqual("Buzz", fizz1.CriarLista()[49]);
        }

    }
}
