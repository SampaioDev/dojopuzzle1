﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace ConsoleApp3
{
    public class FizzBuzz
    {
        public const int numeroInicialDaLista = 1;
        public const int numeroFinalDaLista = 100;
        public FizzBuzz()
        {
            
        }

        public List<String> CriarLista()
        {
            List<String> lista = new List<String>();
            for (int i = numeroInicialDaLista; i <= numeroFinalDaLista; i++)
            {
                
                if ((i % 3 == 0) && (i % 5 == 0))
                {
                    lista.Add("FizzBuzz");
                }
                else if (i % 3 == 0)
                {
                    lista.Add("Fizz");
                }
                else if (i % 5 == 0)
                {
                    lista.Add("Buzz");
                }
                else
                {
                    lista.Add(i.ToString());
                }
            }
            return lista;
        }
    }
}